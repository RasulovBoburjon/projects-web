

        var skewwd = document.querySelector('.skewwd');
        window.addEventListener("scroll",function(){
           var value = -10 + window.scrollY/60;
            skewwd.style.transform = "skewY("+ value +"deg)"
        });