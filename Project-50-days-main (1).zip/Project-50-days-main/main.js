const pannls = document.querySelectorAll('.panel');

pannls.forEach((panel) =>{
    panel.addEventListener('click',() =>{
        removeEventListener()
        panel.classList.add('active');
    })
})


function removeEventListener(){
    pannls.forEach(panel =>{
        panel.classList.remove('active');
    })
}