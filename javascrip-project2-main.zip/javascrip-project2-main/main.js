function clock() {
    let hour = document.getElementById("hour");
    let minutes = document.getElementById("minutes");
    let seconds = document.getElementById("seconds");
    let millisecundes = document.getElementById("millisecundes");

    let h = new Date().getHours();
    let m = new Date().getMinutes();
    let s = new Date().getSeconds();
    let c = new Date().getMilliseconds();

    hour.innerHTML = h; 
    minutes.innerHTML = m; 
    seconds.innerHTML = s; 
    millisecundes.innerHTML = c; 
}

let interval = setInterval(clock,1000);